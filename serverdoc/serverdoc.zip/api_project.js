define({
  "name": "App接口文档",
  "version": "1.0.0",
  "description": "",
  "title": "App接口文档",
  "url": "http://192.168.9.190:20060/app-203/v060/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-07-18T10:36:17.448Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});

define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-07-18T10:34:46.573Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
